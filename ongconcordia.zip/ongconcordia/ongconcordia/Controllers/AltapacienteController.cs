﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ongconcordia.Controllers
{
    public class AltapacienteController : Controller
    {
        //
        // GET: /Altapaciente/
        public ActionResult Index()
        {
            return View();
        }


        //
        // GET: /Altapaciente/Alta
        public ActionResult Alta()
        {
            return View();
        }
	
	}
}