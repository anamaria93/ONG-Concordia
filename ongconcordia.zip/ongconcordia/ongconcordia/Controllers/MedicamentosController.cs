﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ongconcordia.Controllers
{
    public class MedicamentosController : Controller
    {
        //
        // GET: /Medicamentos/
        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /Medicamentos/CrearMedicamentos
        public ActionResult CrearMedic()
        {
            return View();
        }
        }
	}
