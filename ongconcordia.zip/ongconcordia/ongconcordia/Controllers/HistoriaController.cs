﻿using ongconcordia.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ongconcordia.Controllers
{

    [Authorize]
    public class HistoriaController : Controller
    {
        private static Datos.Context contexto =
            new Datos.Context();

        //
        // GET: /Historia/
        public ActionResult Index()
        {
            List<HistoriaClinica> historias = contexto.Historia.OrderBy(p => p.Id).Select(p => new HistoriaClinica()
            {
                Id = p.Id,
                PrimerApellido = p.PrimerApellido,
                SegundoApellido = p.SegundoApellido,
                PrimerNombre = p.PrimerNombre,
                SegundoNombre = p.SegundoNombre,
                NumeroDocumento = p.NumeroDocumento,
                FechaNacimiento = p.FechaNacimiento
            }).ToList();

            return View(historias);
        }

        //
        // GET: /Historia/HistoriaClinica
        public ActionResult Historiaclinica()
        {
            return View();
        }

        public ActionResult Grafico()
        {
            var pacientes = contexto.Pacientes.GroupBy(p => p.FechaNacimiento.Year).Select(p => new { Year = p.Key, Cantidad = p.Count() });
            var datosGrafico = "[";
            if (pacientes.Count() > 0)
            {
                foreach (var valor in pacientes)
                {
                    datosGrafico += "['" + valor.Year + "', " + valor.Cantidad + "],";
                }
                datosGrafico = datosGrafico.Substring(0, datosGrafico.Length - 1);
                datosGrafico += "]";
            }
            else
            {
                datosGrafico = "[]";
            }

            ViewBag.DatosGrafico = datosGrafico;
            return View();

            
        // // GET: /Historia/HistoriaClinica
        public ActionResult Crear()
        {
            EstablecerTiposDocumento();

            return View();
        }

        //
        // POST: /Historia/HistoriaClinica
        [HttpPost]
        public ActionResult Crear(HistoriaClinica historia)
        {
            if (historia.Id == 0)
            {
                Datos.HistoriaClinica historiaNueva = new Datos.HistoriaClinica();
                historiaNueva.FechaNacimiento = historia.FechaNacimiento.Value;
                historiaNueva.IdTipoDocumento = historia.TipoDocumento.Id;
                historiaNueva.NumeroDocumento = historia.NumeroDocumento;
                historiaNueva.PrimerApellido =historia.PrimerApellido;
                historiaNueva.PrimerNombre = historia.PrimerNombre;
                historiaNueva.SegundoApellido = historia.SegundoApellido;
                historiaNueva.SegundoNombre = historia.SegundoNombre;
                historiaNueva.Sexo = historia.Sexo;
                contexto.Historia.Add(historiaNueva);
            }
            else
            {
                Datos.HistoriaClinica historiaActual = contexto.historias.FirstOrDefault(p => p.Id == historia.Id);
                if (historiaActual != null)
                {
                    historiaActual.FechaNacimiento = historia.FechaNacimiento.Value;
                    historiaActual.IdTipoDocumento = historia.TipoDocumento.Id;
                    historiaActual.NumeroDocumento = historia.NumeroDocumento;
                    historiaActual.PrimerApellido = historia.PrimerApellido;
                    historiaActual.PrimerNombre = historia.PrimerNombre;
                    historiaActual.SegundoApellido = historia.SegundoApellido;
                    historiaActual.SegundoNombre = historia.SegundoNombre;
                    historiaActual.Sexo = historia.Sexo;
                }
            }
            contexto.SaveChanges();

            EstablecerTiposDocumento();

            List<HistoriaClinica> historias = contexto.Pacientes.OrderBy(p => p.Id).Select(p => new HistoriaClinica()
            {
                Id = p.Id,
                PrimerApellido = p.PrimerApellido,
                SegundoApellido = p.SegundoApellido,
                PrimerNombre = p.PrimerNombre,
                SegundoNombre = p.SegundoNombre,
                NumeroDocumento = p.NumeroDocumento,
                FechaNacimiento = p.FechaNacimiento,
                TipoDocumento = new TipoDocumento() { Nombre = p.TipoDocumento.Nombre }
            }).ToList();

            return View("Index", historias);
        }

        public ActionResult Editar(int id)
        {
            EstablecerTiposDocumento();

            var pacienteActual = contexto.Pacientes.FirstOrDefault(p => p.Id == id);
            HistoriaClinica historias = new HistoriaClinica();
            if (pacienteActual != null)
            {
                historias.Id = pacienteActual.Id;
                historias.FechaNacimiento = pacienteActual.FechaNacimiento;
                historias.TipoDocumento = new TipoDocumento() { Id = pacienteActual.IdTipoDocumento };
                historias.NumeroDocumento = pacienteActual.NumeroDocumento;
                historias.PrimerApellido = pacienteActual.PrimerApellido;
                historias.PrimerNombre = pacienteActual.PrimerNombre;
                historias.SegundoApellido = pacienteActual.SegundoApellido;
                historias.SegundoNombre = pacienteActual.SegundoNombre;
                historias.Sexo = pacienteActual.Sexo;
            }

            return View("HistoriaClinica", historias);
        }

        public ActionResult Eliminar(int id)
        {
            EstablecerTiposDocumento();

            var pacienteActual = contexto.Pacientes.FirstOrDefault(p => p.Id == id);
            contexto.Pacientes.Remove(pacienteActual);
            contexto.SaveChanges();

            List<HistoriaClinica> pacientes = contexto.Pacientes.OrderBy(p => p.Id).Select(p => new HistoriaClinica()
            {
                Id = p.Id,
                PrimerApellido = p.PrimerApellido,
                SegundoApellido = p.SegundoApellido,
                PrimerNombre = p.PrimerNombre,
                SegundoNombre = p.SegundoNombre,
                NumeroDocumento = p.NumeroDocumento,
                FechaNacimiento = p.FechaNacimiento,
                TipoDocumento = new TipoDocumento() { Nombre = p.TipoDocumento.Nombre }
            }).ToList();

            return View("Index", pacientes);
        }

        private void EstablecerTiposDocumento()
        {
            var tiposDocumento = contexto.TiposDocumento.OrderBy(t => t.Nombre).Select(t => new TipoDocumento()
            {
                Id = t.Id,
                Nombre = t.Nombre
            }).ToList();

            ViewBag.TiposDocumento = tiposDocumento.Select(x => new SelectListItem
            {
                Text = x.Nombre,
                Value = x.Id.ToString()
            });
        }
    }


        }
    
}