﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ongconcordia.Views
{
    public class FormulaMedicaController : Controller
    {
        //
        // GET: /FormulaMedica/
        public ActionResult Index()
        {
            return View();
        }


        // GET: /FormulaMedica/Medicamento
        public ActionResult Medicamento()
        {
            return View();
        }
	}
}