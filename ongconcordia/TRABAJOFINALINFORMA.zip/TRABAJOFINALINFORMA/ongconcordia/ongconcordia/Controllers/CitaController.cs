﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ongconcordia.Controllers
{
    public class CitaController : Controller
    {
        //
        // GET: /Cita/
        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /Cita/AsignacionCita
        public ActionResult AsignacionCita()
        {
            return View();
        }
	}
}