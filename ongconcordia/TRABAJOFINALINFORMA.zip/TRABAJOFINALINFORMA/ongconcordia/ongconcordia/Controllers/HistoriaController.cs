﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ongconcordia.Controllers
{
    public class HistoriaController : Controller
    {
        //
        // GET: /Historia/
        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /Historia/HistoriaClinica
        public ActionResult Historiaclinica()
        {
            return View();
        }
	}
}